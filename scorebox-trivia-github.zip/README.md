# Scorebox Trivia — NBA Quiz

This folder is ready for GitHub Pages.

## Quick deploy (no command line)
1. Create a new repo on GitHub named `scorebox-trivia` (public).
2. Upload `index.html` and `404.html` (drag & drop in the GitHub web UI).
3. Commit the changes.
4. Go to **Settings → Pages**.
5. Under **Build and deployment**, set:
   - Source: **Deploy from a branch**
   - Branch: **main** and **/** (root)
   - Click **Save**.
6. Wait 30–60 seconds, then open: `https://<your-username>.github.io/scorebox-trivia/`

To change the title/header text, edit `index.html` in GitHub and commit.
